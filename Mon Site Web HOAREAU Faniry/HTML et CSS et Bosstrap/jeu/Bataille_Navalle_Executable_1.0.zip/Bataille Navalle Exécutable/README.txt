BONJOUR!
Pour Jouer à la Bataille Navale, Vous devez juste éxécuter le racourci